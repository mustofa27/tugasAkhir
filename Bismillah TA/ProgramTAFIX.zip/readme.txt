1. Untuk menjalankan langsung run file GUI_TA.m
2. Tekan tombol "Select Image" untuk memilih image.
3. Tekan tombol "Process Image" untuk menjalankan proses segmentasi dan klasifikasi.

Catatan:
Gambar hasil preprocessing saya ubah menjadi negatif, biar lebih mudah diamati