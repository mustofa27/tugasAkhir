function [imNrr,y] = NRR(imCup,imDisk)
    mask = imread('mask.png');
    mask = im2bw(mask);
    imNrr = logical(imDisk .* (1-imCup));
    [h,w] = size(imNrr);
    
    mask = imresize(mask,[h w]);
    temporal = sum(sum(imNrr.*mask));
    mask = imrotate(mask,90);
    superior = sum(sum(imNrr.*mask));
    mask = imrotate(mask,90);
    nasal = sum(sum(imNrr.*mask));
    mask = imrotate(mask,90);
    inferior = sum(sum(imNrr.*mask));
    y = (superior+inferior)/(nasal+temporal);
end