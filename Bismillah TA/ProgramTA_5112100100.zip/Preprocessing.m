function y = Preprocessing(x,tipe)
    if(strcmp(tipe,'disk') == 1)
        idx = 1;
    elseif (strcmp(tipe,'cup') == 1)
        idx = 3;
    end
    y = double(x);
    y1 = double(x);
    
    y = imdilate(y,strel('disk',25));
    y = imerode(y,strel('disk',25));
    for i = 1 : idx
        tmp = y1(:);
        xBar = mean(tmp)
        xStd = std(tmp)
        if(strcmp(tipe,'disk') == 1)
            y1 = y1-(xBar);
            y = y-(xBar);
        elseif (strcmp(tipe,'cup') == 1)
            y1 = y1-(xBar+xStd);
            y = y-(xBar+xStd);
        end
    end
    
    y = uint8(y);
    x = y;
    x(x==0) = max(max(y));
    y = uint8(y - min(min(x))*2);
    
end