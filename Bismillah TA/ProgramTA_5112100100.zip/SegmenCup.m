function [cup,area,green] = SegmenCup(I)   
    green = I(:,:,2);
    I = Preprocessing(green,'cup');
    iBw = im2bw(I,graythresh(I));
    
    stats = regionprops(iBw,'basic');
    [b,idx] = sort([stats.Area],'descend')
    index = stats(idx(1)).Centroid;
    index = int32(index);
    iBw = bwareaopen(iBw, b(1));
    cup = iBw;
    area = sum(sum(iBw));
    
end