function y = ISNTBlood(imBlood)
    mask = imread('mask.png');
    mask = im2bw(mask);
    [h,w] = size(imBlood);
    
    mask = imresize(mask,[h w]);
    temporal = sum(sum(imBlood.*mask));
    mask = imrotate(mask,90);
    superior = sum(sum(imBlood.*mask));
    mask = imrotate(mask,90);
    nasal = sum(sum(imBlood.*mask));
    mask = imrotate(mask,90);
    inferior = sum(sum(imBlood.*mask));
    if(nasal+temporal == 0)
        y = 0;
    else
        y = (superior+inferior)/(nasal+temporal);
    end
end