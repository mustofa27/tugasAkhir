function [disk , index, area] = DiscSegmentation(I)
    red = I(:,:,1);
    pre = Preprocessing(red,'disk');
    iBw = im2bw(pre,graythresh(pre));
    stats = regionprops(iBw,'basic');
    [b,idx] = sort([stats.Area],'descend')
    index = stats(idx(1)).Centroid;
    index = int32(index);
    iBw = bwareaopen(iBw, b(1));
    area = b(1);
    disk = iBw;
    
    radius = area/pi;
    ukuran = size(disk);
    lingkaran = zeros(ukuran);
    for i = 1:ukuran(1)
        for j=1:ukuran(2)
            if((index(2)-i)*(index(2)-i)+(index(1)-j)*(index(1)-j) <= radius)
                lingkaran(i,j) = 1;
                if((index(2)-i)*(index(2)-i)+(index(1)-j)*(index(1)-j) <= 100*radius/121 && disk(i,j) == 0)
                    disk(i,j) = 1;
                end
            end
        end
    end
    disk = disk.*lingkaran;
    
end